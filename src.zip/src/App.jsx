import logo from './logo.svg';
import './App.css';
import ProductDetails from './components/ProductDetails/ProductDetails';
import GlassesNew from './components/GlassesNew/GlassesNew';
import { Outlet } from 'react-router-dom';
import NavigationBar from './components/NavigationBar/NavigationBar';
import Home from './components/Home/Home';
import Cart from './components/Cart/Cart';

function App() {
  return (
    <div className="App">

      
      <NavigationBar></NavigationBar>
      {/* <Home></Home> */}
      <Outlet></Outlet>
      

      {/* <GlassesNew></GlassesNew> */}
      
    </div>
  );
}

export default App;

