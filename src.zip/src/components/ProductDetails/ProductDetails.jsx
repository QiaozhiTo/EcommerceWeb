import React from "react";
import allDatas from "../../datas/data_origin";
import { getData } from "../../datas/data_origin";
import './ProductDetails.css';
import { useParams,useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";

export default function ProductDetails() {
    // let data = allDatas()
    let params = useParams()
    console.log(params);
    let filterProduct = getData(params.productId)
    console.log(filterProduct)
    let navigate = useNavigate()
    let click = ()=>{
        navigate('/glasses')
    }

  return (
    <div>
        <div className="mainContent">
            <div className="productView"> 

                <Link to={'/glasses'}> <h3 className="backButton">Back To Shop</h3>
                </Link>

                <div className="productModel">
                    <div className="imgCollection">
                        <img className="imgSide" src={filterProduct.img} alt=''></img>
                    </div>
                    <div className="imgWrapper">
                        <img className='productImg' src={filterProduct.img} alt=''></img>
                    </div>

                    <div className="modelDetails">
                        <span className="brand">{filterProduct.brand}</span>
                        <h1>{filterProduct.name}</h1>
                        <div className="desc">{filterProduct.desc}</div>
                        <h1 className="price">${filterProduct.price}.00</h1>
                        
                        <div className="modelAction">
                            <div className="select" onClick={click}>Add to Basket</div>
                        </div>
                    </div>
                </div>


            </div>
        {/* <img src={filterProduct.img} alt=''></img> */}
        {/* <div>{filterProduct.brand}</div> */}
        {/* <div>{filterProduct.price}</div> */}

        </div>




        
    </div>
  )
}
