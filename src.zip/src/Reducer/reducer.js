import allDatas from "../datas/data_origin";
import { addToCarts } from "../Action/actionType";
let data = allDatas()
let rootReducer = () =>{
    
}